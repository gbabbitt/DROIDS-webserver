Clazz.declarePackage ("J.api.js");
Clazz.declareInterface (J.api.js, "JSConsole");
